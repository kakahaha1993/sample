'''
import openai
from pydub import AudioSegment
import io

openai.api_key = "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"
sound = AudioSegment.from_wav("./outputFfmpeg/2-242変数（数値×数値）の特徴量生成(cut済み).wav")
audio = sound[0: 5000]
file_path = '.\\work\\2-242変数（数値×数値）の特徴量生成(cut済み)_{0}.wav'.format(0)
audio.export(file_path)

audio_file= open(file_path, "rb")
# response_formatを指定することで文字起こしファイルを作成できる。（デフォルトはjson）
transcript = openai.Audio.transcribe("whisper-1", audio_file, language="ja")
print(transcript["text"])
'''

from faster_whisper import WhisperModel
# Download audio from Youtube

model = WhisperModel("large-v3", device="cuda", compute_type="float16")
file_path = "C:\\Users\\kitaw\\OneDrive\\ドキュメント\\プレミア\\はやたす\\書き出し\\6-74汎化性能を上げるための最重要アクション(cut済み).mp4"

segments, info = model.transcribe(
	file_path,
	beam_size=5,
	vad_filter=True,)
	
print("Detected language '%s' with probability %f" % (info.language, info.language_probability))
for segment in segments:
    print(segment.text)