from pydub import AudioSegment
from pydub.silence import split_on_silence
import datetime
import math
import openai
import whisper
import re

openai.api_key = "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"
FRAMELATE = 0.03333333 #30フレーム

def whisper_exe(filename):
    model = whisper.load_model("large-v3", device="cuda:0")
    result = model.transcribe(filename, language="ja", word_timestamps=True)
    return result

def set_text_time(text_list, list):
    start_time = None
    end_time = None
    result = []
    counter = 0
    for data in text_list:
        message = ""
        if data == "":
            continue
        for i in range(counter, len(list)):
            counter = i + 1
            message = message + list[i][2]
            if start_time == None:
                start_time = list[i][0]
            if str(data).replace(" ", "") == str(message).replace("。", "").replace("、", "").replace(" ", ""):
                end_time = list[i][1]
                result.append([start_time, end_time, data])
                start_time = None
                break
    return result

def format_timedelta(timedelta):
  total_sec = timedelta.total_seconds()
  millisecondes, _ = math.modf(total_sec)
  millisecondes = millisecondes / FRAMELATE
  # hours
  hours = total_sec // 3600 
  # remaining seconds
  remain = total_sec - (hours * 3600)
  # minutes
  minutes = remain // 60
  # remaining seconds
  seconds = remain - (minutes * 60)
  # total time
  return '{:02}:{:02}:{:02}:{:02}'.format(int(hours), int(minutes), int(seconds), int(millisecondes))


def get_chatgpt_by_text_end(text):
    message = '''下記文章の終わりに「。」を追記してください。
文章の区切りに「、」を追記してください。
また、文章の修正はしないでください。
出力は修正後の文章のみ出力してください。

文章[{0}]'''.format(text)
    #print(message)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": message},
        ],
        temperature = 0
    )
    content = response.choices[0]["message"]["content"].strip()
    print(content)
    return content

def get_chatgpt(text):
    message = '''あなたは動画編集者です。
文章の意味を変えないように誤字がある部分を校正してください。

文章[{0}]'''.format(text)
    #print(message)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": message},
        ],
        temperature = 0
    )
    content = response.choices[0]["message"]["content"].strip()
    print(content)
    return content

def format_time(data):
    NUMBER_OF_DIGITS = 1000 #桁数(小数点3桁)
    seconds = int(data)
    millisecondes = str(data * NUMBER_OF_DIGITS - seconds * NUMBER_OF_DIGITS)
    millisecondes = int("0." + millisecondes[:-2]) / FRAMELATE
    td = datetime.timedelta(seconds=seconds)
    time = format_timedelta(td, millisecondes)

    return time

def convert_time_list(times):
    list = []
    delete_flag_list = []
    diff_time = "00:00:00:00"
    NUMBER_OF_DIGITS = 1000 #桁数(小数点3桁)
    for time in times:
        seconds = int(time[0])
        millisecondes = str(time[0] * NUMBER_OF_DIGITS - seconds * NUMBER_OF_DIGITS)
        millisecondes = millisecondes[:-2]
        td = datetime.timedelta(seconds=seconds, milliseconds=int(millisecondes))
        start_time = format_timedelta(td)
        if start_time != diff_time:
           delete_flag_list.append(1)
           delete_flag_list.append(0)
        else:
           delete_flag_list.append(0)
        #print('start_time: ', format_timedelta(td))
        seconds = int(time[1])
        millisecondes = str(time[1] * NUMBER_OF_DIGITS - seconds * NUMBER_OF_DIGITS)
        millisecondes = millisecondes[:-2]
        td = datetime.timedelta(seconds=seconds, milliseconds=int(millisecondes))
        #print('end_time: ', format_timedelta(td))
        end_time = format_timedelta(td)
        diff_time = end_time
        
        list.append([start_time, end_time])
    return list, delete_flag_list



#times = [[0, 1165], [4111, 4465], [10548, 12510], [14624, 15371], [17441, 18630], [20489, 21023], [24628, 28893], [33179, 33853], [34677, 39132], [44006, 48073], [49188, 50764], [52246, 64392], [67720, 70755], [72028, 74580], [83848, 87189], [89755, 102288], [104850, 105337]]
#print(convert_time_list(times))

result = whisper_exe(".\\separated\\htdemucs\\動画編集キャンプ素材(raw)\\vocals.wav")
#print(whisper_list)
text_list = []
list = []
for recode in result['segments']:
    text_list.append(recode["text"])
    for word in recode["words"]:
        list.append([
            word['start'],
            word['end'],
            word['word']
        ])
text = get_chatgpt_by_text_end("\n".join(text_list))
#text = "はいどうもアオです。今回ですね、動画編集なんてもうオワコンだよって話をしていきたいなというふうに思います。これからはですね、新聞配達が稼げるんですね。新聞配達で稼げるわけねえじゃんって怒る方もいるかもしれないんですが、これから新聞配達なんですよ。せっかく動画編集頑張って始めようと思ったのにーって悲しい人もいるかもしれませんが、やっぱりね、新聞配達がこれから一番儲かるビジネスなんですね。 なので皆さんね、今すぐこのパソコンを投げ捨ててですね、新聞配達これを始めてみてはいかがでしょうか。新聞配達新聞配達新聞配達です。しっかりね、しっかり配達しまくってね、今の時代もキャッシュレスとか ないですから新聞がいいんですからね。新聞が時代ですからしっかり新聞で稼いでいきましょう。そんなわけで今回は以上です。ありがとうございました。"
#list = [[0.0, 0.16, 'はい'], [0.16, 0.3, 'どう'], [0.3, 0.32, 'も'], [0.32, 0.44, 'ア'], [0.44, 0.48, 'オ'], [0.48, 0.54, 'です。'], [0.74, 1.02, '今回'], [1.02, 1.26, 'ですね'], [1.26, 1.7, '動画'], [1.7, 2.02, '編'], [2.02, 2.22, '集'], [2.22, 2.36, 'なん'], [2.36, 2.5, 'て'], [2.5, 2.6, 'もう'], [2.6, 2.76, 'オ'], [2.76, 2.82, 'ワ'], [2.82, 2.92, 'コ'], [2.92, 3.04, 'ン'], [3.04, 3.14, 'だ'], [3.14, 3.26, 'よ'], [3.26, 3.34, 'って'], [3.34, 3.52, '話'], [3.52, 3.7, 'を'], [3.7, 3.82, 'して'], [3.82, 3.94, 'いき'], [3.94, 4.06, 'たい'], [4.06, 4.18, 'な'], [4.18, 4.34, 'という'], [4.34, 4.5, 'ふ'], [4.5, 4.5, 'う'], [4.5, 4.58, 'に'], [4.58, 4.68, '思'], [4.68, 4.92, 'います。'], [5.02, 5.3, 'これ'], [5.3, 5.5, 'から'], [5.5, 5.58, 'は'], [5.58, 5.76, 'ですね'], [5.76, 6.4, '新聞'], [6.4, 6.72, '配'], [6.72, 6.94, '達'], [6.94, 7.06, 'が'], [7.06, 7.26, '稼'], [7.26, 7.38, 'げ'], [7.38, 7.44, 'る'], [7.44, 7.52, 'ん'], [7.52, 7.7, 'ですね。'], [7.82, 8.1, '新聞'], [8.1, 8.34, '配'], [8.34, 8.46, '達'], [8.46, 8.54, 'で'], [8.54, 8.68, '稼'], [8.68, 8.78, 'げ'], [8.78, 8.84, 'る'], [8.84, 8.88, 'わ'], [8.88, 8.88, 'け'], [8.88, 8.98, 'ね'], [8.98, 9.04, 'え'], [9.04, 9.14, 'じゃ'], [9.14, 9.22, 'ん'], [9.22, 9.38, 'って'], [9.38, 9.78, '怒'], [9.78, 9.88, 'る'], [9.88, 10.02, '方'], [10.02, 10.12, 'も'], [10.12, 10.22, 'いる'], [10.22, 10.36, 'か'], [10.36, 10.44, 'もし'], [10.44, 10.62, 'れない'], [10.62, 10.76, 'んです'], [10.76, 10.94, 'が、'], [10.96, 11.18, 'これ'], [11.18, 11.32, 'から'], [11.32, 11.52, '新聞'], [11.52, 11.92, '配'], [11.92, 12.08, '達'], [12.08, 12.26, 'なんです'], [12.26, 12.54, 'よ。'], [12.6, 12.8, 'せ'], [12.8, 12.92, 'っ'], [12.92, 13.0, 'か'], [13.0, 13.06, 'く'], [13.06, 13.28, '動画'], [13.28, 13.56, '編'], [13.56, 13.72, '集'], [13.72, 13.94, '頑'], [13.94, 14.06, '張'], [14.06, 14.2, 'って'], [14.2, 14.3, '始'], [14.3, 14.44, 'め'], [14.44, 14.5, 'よう'], [14.5, 14.62, 'と思'], [14.62, 14.8, 'った'], [14.8, 14.94, 'の'], [14.94, 15.02, 'に'], [15.02, 15.18, 'ー'], [15.18, 15.34, 'って'], [15.34, 16.0, '悲'], [16.0, 16.2, 'しい'], [16.2, 16.38, '人'], [16.38, 16.48, 'も'], [16.48, 16.58, 'いる'], [16.58, 16.64, 'か'], [16.64, 16.78, 'もし'], [16.78, 16.84, 'れ'], [16.84, 17.02, 'ません'], [17.02, 17.22, 'が、'], [17.28, 17.5, 'や'], [17.5, 17.64, 'っぱ'], [17.64, 17.72, ' り'], [17.72, 17.78, 'ね'], [17.78, 18.4, '新聞'], [18.4, 18.7, '配'], [18.7, 18.84, '達'], [18.84, 19.0, 'が'], [19.0, 19.26, 'これ'], [19.26, 19.42, 'から'], [19.42, 19.58, '一'], [19.58, 19.88, '番'], [19.88, 20.4, '儲'], [20.4, 20.56, 'か'], [20.56, 20.6, 'る'], [20.6, 20.76, 'ビ'], [20.76, 20.92, 'ジ'], [20.92, 20.94, 'ネ'], [20.94, 21.02, 'ス'], [21.02, 21.12, 'なん'], [21.12, 21.34, 'ですね。'], [21.46, 21.74, 'なので'], [21.74, 22.04, '皆さん'], [22.04, 22.26, 'ね'], [22.26, 22.54, '今'], [22.54, 22.68, 'す'], [22.68, 22.82, 'ぐ'], [22.82, 22.94, 'この'], [22.94, 23.1, 'パ'], [23.1, 23.22, 'ソ'], [23.22, 23.32, 'コ'], [23.32, 23.42, 'ン'], [23.42, 23.44, 'を'], [23.44, 23.6, '投'], [23.6, 23.8, 'げ'], [23.8, 23.88, '捨'], [23.88, 23.96, 'て'], [23.96, 24.04, 'て'], [24.04, 24.28, 'ですね'], [24.28, 24.74, '新聞'], [24.74, 24.94, '配'], [24.94, 25.06, '達'], [25.06, 25.38, 'これ'], [25.38, 25.48, 'を'], [25.48, 25.58, '始'], [25.58, 25.74, 'めて'], [25.74, 25.82, 'み'], [25.82, 25.96, 'て'], [25.96, 26.1, 'はい'], [26.1, 26.32, 'か'], [26.32, 26.42, 'が'], [26.42, 26.68, 'でしょう'], [26.68, 26.96, 'か。'], [26.96, 27.28, '新聞'], [27.28, 27.44, '配'], [27.44, 27.54, '達'], [27.54, 27.96, '新聞'], [27.96, 28.18, '配'], [28.18, 28.3, '達'], [28.3, 28.66, '新聞'], [28.66, 28.96, '配'], [28.96, 29.1, '達'], [29.1, 29.22, 'です。'], [29.62, 29.9, 'し'], [29.9, 30.0, 'っ'], [30.0, 30.2, 'か'], [30.2, 30.24, 'り'], [30.24, 30.34, 'ね'], [30.34, 30.66, 'し'], [30.66, 30.74, 'っ'], [30.74, 31.02, 'か'], [31.02, 31.14, 'り'], [31.14, 31.38, '配'], [31.38, 31.58, '達'], [31.58, 31.74, 'しま'], [31.74, 31.84, 'く'], [31.84, 31.98, 'って'], [31.98, 32.1, 'ね'], [32.1, 32.52, '今'], [32.52, 32.68, 'の'], [32.68, 32.8, '時'], [32.8, 32.96, '代'], [32.96, 33.04, 'も'], [33.04, 33.42, 'キ'], [33.42, 33.54, 'ャ'], [33.54, 33.54, 'ッ'], [33.54, 33.6, 'シ'], [33.6, 33.66, 'ュ'], [33.66, 33.74, 'レ'], [33.74, 33.8, 'ス'], [33.8, 33.94, 'とか'], [33.94, 34.48, 'ない'], [34.48, 34.64, 'です'], [34.64, 34.78, 'から'], [34.78, 35.52, '新聞'], [35.52, 35.8, 'が'], [35.8, 36.08, 'いい'], [36.08, 36.26, 'んです'], [36.26, 36.42, 'から'], [36.42, 36.58, 'ね。'], [36.82, 37.1, '新聞'], [37.1, 37.3, 'が'], [37.3, 37.44, '時'], [37.44, 37.58, '代'], [37.58, 37.7, 'です'], [37.7, 37.88, 'から'], [37.88, 38.28, 'し'], [38.28, 38.34, 'っ'], [38.34, 38.44, 'か'], [38.44, 38.48, 'り'], [38.48, 38.78, '新聞'], [38.78, 39.0, 'で'], [39.0, 39.16, '稼'], [39.16, 39.3, 'い'], [39.3, 39.36, 'で'], [39.36, 39.44, 'いき'], [39.44, 39.76, 'ましょう。'], [39.92, 40.12, 'そんな'], [40.12, 40.24, 'わ'], [40.24, 40.26, 'け'], [40.26, 40.36, 'で'], [40.36, 40.5, '今回'], [40.5, 40.66, 'は'], [40.66, 40.8, '以上'], [40.8, 40.9, 'です。'], [40.92, 41.08, 'ありがとうございました。']]
text_list = re.split('[。、]', text)
print(text_list)
print(list)
text_time = set_text_time(text_list, list)
print(text_time)
#data = convert_time_list(text_time)
#print(data)

'''
sound = AudioSegment.from_wav(".\\separated\\htdemucs\\動画編集キャンプ素材\\vocals.wav")
list = split_on_silence(sound, 
                min_silence_len = 100,
                silence_thresh = -50,
                keep_silence = 100,
                with_timing = True)
marge_audio = AudioSegment.empty()
audio_list = []
audio_list = [[570, 1350], [3037, 3290], [4096, 4606], [10528, 10858], [10763, 11048], [11133, 12612], [14460, 14665], [14623, 15602], [17376, 18228], [18337, 18652], [20450, 21144], [24602, 28998], [33147, 34014], [34669, 35689], [35736, 36017], [36375, 39241], [43890, 44854], [44869, 46682], [46595, 48165], [49152, 50810], [52239, 55268], [55409, 57191], [57332, 58129], [58092, 60154], [60134, 61558], [61789, 62873], [63158, 64466], [67398, 67636], [67705, 70848], [72000, 72765], [72675, 74768], [77234, 77441], [83799, 84500], [84519, 85206], [85289, 86138], [86315, 86788], [86751, 87245], [89719, 90195], [90117, 91573], [91670, 93476], [93480, 94326], [94504, 96034], [96610, 97955], [97979, 99981], [99935, 100418], [100852, 102383], [104833, 105337]]
#cutted_sound = sum(chunks)

data = convert_time_list(audio_list)
print(data[1])
print(len(data[1]))
'''
#marge_audio.export('cutted4.wav')
#print(audio_list)
