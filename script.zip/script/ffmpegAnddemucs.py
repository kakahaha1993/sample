import ffmpeg 
from pydub import AudioSegment
import subprocess

# 入力 
filename = "テスト素材(カットのみ)"
stream = ffmpeg.input("C:\\Users\\kitaw\\OneDrive\\ドキュメント\\プレミア\\ひなみん\\書き出し\\{0}.mp4".format(filename)) 
# 出力 
stream = ffmpeg.output(stream, ".\\outputFfmpeg\\{0}.wav".format(filename)) 

# 実行
ffmpeg.run(stream)
result = subprocess.run(["demucs", "--two-stems=vocals", ".\\outputFfmpeg\\{0}.wav".format(filename), "-d", "cuda"])
