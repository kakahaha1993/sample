import soundfile as sf
import numpy as np
from matplotlib import pyplot as plt
from pydub import AudioSegment
import subprocess

def mk_starts_ends(movie):
    output = subprocess.run(["ffmpeg", "-i", movie, "-af", "silencedetect=noise=-33dB:d=0.6", "-f", "null", "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print(output)
    s = str(output)
    lines = s.split('\\n')
    time_list =[]
    for line in lines:
        if "silencedetect" in line:
            words = line.split(" ")
            for i in range(len(words)):
                if "silence_start" in words[i]:
                    time_list.append(float(words[i+1].replace("\\r", "")))
                if "silence_end" in words[i]:
                    time_list.append(float(words[i+1].replace("\\r", "")))
    print(time_list)
    starts_ends = list(zip(*[iter(time_list)]*2))
    return starts_ends

#data, samplerate = sf.read(".\\separated\\htdemucs\\動画編集キャンプ素材\\vocals.wav")
'''
sounds = AudioSegment.from_wav(".\\separated\\htdemucs\\動画編集キャンプ素材\\vocals.wav")
for sound in sounds:
    if  sound.max_dBFS > -35:
        print(sound.max_dBFS, sound.duration_seconds)
'''
mk_starts_ends(".\\vocals.wav")

'''
data, samplerate = sf.read(".\\動画編集キャンプ素材.wav")
t = np.arange(0, len(data))/samplerate
plt.figure(figsize=(18, 6))
amp = np.abs(data)
plt.plot(t, amp)
thres = 0.05
b = amp > thres
print(float(amp[0][0]))

min_silence_duration = 0.5
silences = []
prev = 0
entered = 0
for i, v in enumerate(b):
  print(v)
  if prev == 1 and v == 0: # enter silence
    entered = i
  if prev == 0 and v == 1: # exit silence
    duration = (i - entered) / samplerate 
    if duration > min_silence_duration:
      silences.append({"from": entered, "to": i, "suffix": "cut"})
      entered = 0
  prev = v
if entered > 0 and entered < len(b):
  silences.append({"from": entered, "to": len(b), "suffix": "cut"})
plt.plot(t, silences)
'''

#plt.show()
