import xml.etree.ElementTree as ET
import math
from pydub import AudioSegment
import ffmpeg 
import openai
import json
import xmltodict
import datetime
from faster_whisper import WhisperModel

openai.api_key = "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"
model = WhisperModel("large-v3", device="cuda", compute_type="float16")

def whisper_exe(audio_file):
    # result = model.transcribe("準備したファイル名を指定") # 今回の記事ではtest.m4aを用います。
    #transcript = openai.Audio.transcribe("whisper-1", audio_file, language="ja")
    transcript = ""
    segments, info = model.transcribe(
	audio_file,
	beam_size=5,
	vad_filter=True)
    for segment in segments:
         transcript = transcript + segment.text
    return transcript

def format_timedelta(timedelta, millisecondes: str):
    total_sec = timedelta.total_seconds()
    # hours
    hours = total_sec // 3600 
    # remaining seconds
    remain = total_sec - (hours * 3600)
    # minutes
    minutes = remain // 60
    # remaining seconds
    seconds = remain - (minutes * 60)
    # total time
    return '{:02}:{:02}:{:02},{:03}'.format(int(hours), int(minutes), int(seconds), millisecondes.ljust(3, '0'))

def format_time(time_str: str):
	dot_index = time_str.find(".")
	time = ""
	if dot_index == -1:
		td = datetime.timedelta(seconds=0)
		time = format_timedelta(td, "000")
	else:
		seconds = int(time_str[:dot_index])
		millisecondes = time_str[dot_index + 1:dot_index + 4]
		td = datetime.timedelta(seconds=seconds)
		time = format_timedelta(td, millisecondes)

	return time

def run(filename: str, clips):
	#xmlデータを読み込みます
	#file_path = "C:\\Users\\kitaw\\OneDrive\\ドキュメント\\プレミア\\はやたす\\書き出し\\【テスト用】はやたすさん講座動画(6-24).mp4"
	file_path = filename
	path_list = file_path.split("\\")
	filename = path_list[len(path_list) - 1].replace(".mp4", "")
	stream = ffmpeg.input(file_path) 
	stream = ffmpeg.output(stream, ".\\outputFfmpeg\\{0}.wav".format(filename)) 
	ffmpeg.run(stream, overwrite_output=True)
	counter = 0
	text_time = []
	sound = AudioSegment.from_wav(".\\outputFfmpeg\\{0}.wav".format(filename))
	for clip in clips:
		start = clip["start"]
		end = clip["end"]
		start_time = start * 1000
		end_time = end * 1000
		start_str = format_time(str(clip["start"]))
		end_str = format_time(str(clip["end"]))

		audio = sound[start_time: end_time]
		audio.export('.\\work\\{0}_{1}.wav'.format(filename, counter))
		audio_file= open('.\\work\\{0}_{1}.wav'.format(filename, counter), "rb")
		#print("整数：", math.floor((start * 1000) * (1/30)), math.floor((end * 1000) * (1/30)))
		#print("少数：", math.floor((start * 1000) * (1/30)) / 1000 , math.floor((end * 1000) * (1/30)) / 1000)
		whisper_result = whisper_exe(audio_file)
		counter = counter + 1
		#text_time.append([start_time_str, end_time_str, whisper_result["text"]])
		print(whisper_result)
		text_time.append([start_str, end_str, whisper_result])
	f = open('.\\outputTxt\\{0}.txt'.format(filename), 'w', encoding="utf_8_sig")
	f.write(json.dumps(text_time, ensure_ascii=False))
	f.close()
	#with open('.\\outputTxt\\{0}.txt'.format(filename), mode='rt', encoding='utf_8_sig') as f:
	#    json_text = f.read().replace("\t", "").replace("\n", "")
	#text_time = json.loads(json_text)
	result_text = ""
	for i, data in enumerate(text_time):
		start_time = data[0]
		end_time = data[1]
		result_text = result_text + str(i + 1) + "\n"
		result_text = result_text + "{0} --> {1}".format(start_time, end_time) + "\n"
		result_text = result_text + str(data[2]) + "\n\n"
	print(result_text)
	f = open('.\\outputSrt\\{0}.srt'.format(filename), 'w', encoding="utf_8_sig")
	f.write(result_text)
	f.close()

#data = [{'start': 0, 'end': 3.06973333333333}, {'start': 3.06973333333333, 'end': 4.33766666666667}, {'start': 4.33766666666667, 'end': 9.27593333333333}, {'start': 9.27593333333333, 'end': 10.4437666666667}, {'start': 10.4437666666667, 'end': 13.3466666666667}, {'start': 13.3466666666667, 'end': 18.4851333333333}, {'start': 18.4851333333333, 'end': 22.4891333333333}, {'start': 22.4891333333333, 'end': 24.5245}, {'start': 24.5245, 'end': 27.4607666666667}, {'start': 27.4607666666667, 'end': 32.032}, {'start': 32.032, 'end': 35.6022333333333}, {'start': 35.6022333333333, 'end': 38.6052333333333}, {'start': 38.6052333333333, 'end': 43.1764666666667}, {'start': 43.1764666666667, 'end': 45.1451}, {'start': 45.1451, 'end': 48.0813666666667}, {'start': 48.0813666666667, 'end': 50.9842666666667}, {'start': 50.9842666666667, 'end': 53.8538}, {'start': 53.8538, 'end': 56.2895666666667}, {'start': 56.2895666666667, 'end': 57.9912666666667}, {'start': 57.9912666666667, 'end': 61.1611}, {'start': 61.1611, 'end': 62.5291333333333}, {'start': 62.5291333333333, 'end': 64.7313333333333}, {'start': 64.7313333333333, 'end': 66.1661}, {'start': 66.1661, 'end': 67.8678}, {'start': 67.8678, 'end': 70.7707}, {'start': 70.7707, 'end': 72.9061666666667}, {'start': 72.9061666666667, 'end': 76.7433333333333}, {'start': 76.7433333333333, 'end': 80.2134666666667}, {'start': 80.2134666666667, 'end': 83.0496333333333}, {'start': 83.0496333333333, 'end': 85.1851}, {'start': 85.1851, 'end': 87.4874}, {'start': 87.4874, 'end': 88.3549333333333}, {'start': 88.3549333333333, 'end': 94.3943}, {'start': 94.3943, 'end': 97.6976}, {'start': 97.6976, 'end': 103.970533333333}, {'start': 103.970533333333, 'end': 106.7066}, {'start': 106.7066, 'end': 108.475033333333}, {'start': 108.475033333333, 'end': 112.045266666667}, {'start': 112.045266666667, 'end': 115.115}, {'start': 115.115, 'end': 120.2201}, {'start': 120.2201, 'end': 123.189733333333}, {'start': 123.189733333333, 'end': 124.090633333333}, {'start': 124.090633333333, 'end': 127.3272}, {'start': 127.3272, 'end': 131.097633333333}, {'start': 131.097633333333, 'end': 134.200733333333}]
#run(data)