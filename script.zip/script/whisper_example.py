import datetime
import math
import whisper
import openai
import re
import ffmpeg 

openai.api_key = "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"

def whisper_exe(filename):
    model = whisper.load_model("large", device="cuda:0")
    # result = model.transcribe("準備したファイル名を指定") # 今回の記事ではtest.m4aを用います。
    result = model.transcribe(filename, language="ja", word_timestamps=True)
    return result

def set_text_time(text_list, list):
    start_time = None
    end_time = None
    result = []
    counter = 0
    for data in text_list:
        message = ""
        if data == "":
            continue
        for i in range(counter, len(list)):
            counter = i + 1
            message = message + list[i][2]
            if start_time == None:
                start_time = list[i][0]
            if str(data).replace(" ", "") == str(message).replace("。", "").replace("、", "").replace(" ", ""):
                end_time = list[i][1]
                result.append([start_time, end_time, data])
                start_time = None
                break
    return result

def format_timedelta(timedelta, millisecondes: str):
    total_sec = timedelta.total_seconds()
    # hours
    hours = total_sec // 3600 
    # remaining seconds
    remain = total_sec - (hours * 3600)
    # minutes
    minutes = remain // 60
    # remaining seconds
    seconds = remain - (minutes * 60)
    # total time
    return '{:02}:{:02}:{:02},{:03}'.format(int(hours), int(minutes), int(seconds), millisecondes.ljust(3, '0'))

def format_time(data):
    NUMBER_OF_DIGITS = 1000 #桁数(小数点3桁)
    seconds = int(data)
    millisecondes = str(data * NUMBER_OF_DIGITS - seconds * NUMBER_OF_DIGITS)
    millisecondes = millisecondes[:-2]
    td = datetime.timedelta(seconds=seconds)
    time = format_timedelta(td, millisecondes)

    return time

def get_chatgpt_by_text_end(text):
    message = '''下記文章の終わりに改行してください。
また、文章の修正はしないでください。
出力は修正後の文章のみ出力してください。

文章[{0}]'''.format(text)
    #print(message)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": message},
        ],
        temperature = 0
    )
    content = response.choices[0]["message"]["content"].strip()
    print(content)
    return content

def get_chatgpt(text):
    message = '''あなたは動画編集者です。
文章の意味を変えないように誤字がある部分を校正してください。

文章[{0}]'''.format(text)
    #print(message)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": message},
        ],
        temperature = 0
    )
    content = response.choices[0]["message"]["content"].strip()
    print(content)
    return content

def get_chatgpt(text):
    message = '''あなたは動画編集者です。
下記文章から1行ごとに喜怒哀楽を判定してください。
特に何もない場合は「無」を表示してください。

文章[{0}]
出力：[文章：喜怒哀楽]'''.format(text)
    #print(message)
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "user", "content": message},
        ],
        temperature = 0
    )
    content = response.choices[0]["message"]["content"].strip()
    print(content)
    return content

def main():
    file_path = "C:\\Users\\kitaw\\OneDrive\\ドキュメント\\プレミア\\はやたす\\書き出し\\6-27時系列データの特徴量生成(cut済み).mp4"
    path_list = file_path.split("\\")
    filename = path_list[len(path_list) - 1].replace(".mp4", "")
    stream = ffmpeg.input(file_path) 
    stream = ffmpeg.output(stream, ".\\outputFfmpeg\\{0}.wav".format(filename)) 
    ffmpeg.run(stream, overwrite_output=True)
    result = whisper_exe(".\\outputFfmpeg\\{0}.wav".format(filename))
    text_list = []
    list = []
    for recode in result['segments']:
        text_list.append(recode["text"])
        for word in recode["words"]:
            list.append([
                word['start'],
                word['end'],
                word['word']
            ])
    text = get_chatgpt_by_text_end("\n".join(text_list))
    print(list)
    text_list = re.split('\n', text)
    text_time = set_text_time(text_list, list)
    print(text_time)

    result_text = ""
    for i, data in enumerate(text_time):
        start_time = format_time(data[0])
        if i != 0:
            start_time = format_time(text_time[i - 1][1])
        end_time = format_time(data[1])
        result_text = result_text + str(i + 1) + "\n"
        result_text = result_text + "{0} --> {1}".format(start_time, end_time) + "\n"
        result_text = result_text + str(data[2]) + "\n\n"
    f = open('.\\outputSrt\\{0}.srt'.format(filename), 'w', encoding="utf_8_sig")
    f.write(result_text)
    f.close()
    
main()
