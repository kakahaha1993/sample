import time
import win32gui
import ctypes
import pyautogui

def get_window_title(search):

    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int))

    EnumWindows = ctypes.windll.user32.EnumWindows
    # タイトル格納用変数
    titles = []
    def foreach_window(hwnd, lparam):
        if ctypes.windll.user32.IsWindowVisible(hwnd):
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            buff = ctypes.create_unicode_buffer(length +1)
            ctypes.windll.user32.GetWindowTextW(hwnd, buff, length + 1)
            titles.append(buff.value)
            return True
    EnumWindows(EnumWindowsProc(foreach_window), 0)
    for title in titles:
        if title == '':
            continue
        if search in title:
            print(title)
            return title
    #print(titles)

if __name__ == '__main__':
    title = get_window_title("Adobe Premiere Pro 2024")
    memoapp = win32gui.FindWindow(None, title)
    win32gui.SetForegroundWindow(memoapp)
    pyautogui.keyDown('shift')
    pyautogui.press('3')
    pyautogui.keyUp('shift')
    pyautogui.press("up")
    splits = [[0, 663], [1257, 4121], [4598, 10563], [12637, 14624], [15481, 17488], [18772, 20504], [21127, 24680], [29033, 33260], [33958, 34766], [35692, 36400], [39274, 44027], [48214, 49191], [50898, 52251], [57154, 57337], [61624, 61820], [62914, 63187], [64525, 67727], [70897, 72042], [74723, 83850], [86141, 86600], [87328, 89767], [94362, 94539], [96096, 96674], [100414, 100890], [102369, 104857]]

    for i, split in enumerate(splits):
        if i == 0:
            pyautogui.keyDown('shift')
            pyautogui.press('m')
            pyautogui.keyUp('shift')
            pyautogui.press('a')
            pyautogui.keyDown('shift')
            pyautogui.press('m')
            pyautogui.keyUp('shift')
            continue
        pyautogui.keyDown('shift')
        pyautogui.press('m')
        pyautogui.keyUp('shift')
        pyautogui.press('s')
        pyautogui.keyDown('shift')
        pyautogui.press('m')
        pyautogui.keyUp('shift')
        pyautogui.press('a')
        pyautogui.keyDown('shift')
        pyautogui.press('m')
        pyautogui.keyUp('shift')
    pyautogui.keyUp('shift')
