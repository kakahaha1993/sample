
from flask import Flask, request
import noVoiceCut as nv
import telop

app = Flask(__name__, static_folder='.', static_url_path='')
@app.after_request
def after_request(response):
  response.headers.add('Access-Control-Allow-Origin', '*')
  response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
  response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
  return response

@app.route('/noVoiceCut', methods=["POST"])
def noVoiceCut():
    print(request.json['filename'])
    response = nv.Cut(request.json['filename'])
    #path = request.json['filename'].split("\\")
    #filename = path[len(path) - 1]
    #print(filename)
    return response

@app.route('/telop', methods=["POST"])
def clips():
    print(request.json['clips'])
    telop.run(request.json['filename'], request.json['clips'])
    #response = nv.Cut(request.json['filename'])
    #path = request.json['filename'].split("\\")
    #filename = path[len(path) - 1]
    #print(filename)
    return ""

app.run(port=8000, debug=True)