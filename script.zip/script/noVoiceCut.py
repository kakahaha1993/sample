from pydub import AudioSegment
from pydub.silence import split_on_silence
import datetime
import math
import ffmpeg 
import datetime

FRAMELATE = 0.03333333 #30フレーム

def format_timedelta(timedelta):
  total_sec = timedelta.total_seconds()
  millisecondes, _ = math.modf(total_sec)
  millisecondes = millisecondes / FRAMELATE
  # hours
  hours = total_sec // 3600 
  # remaining seconds
  remain = total_sec - (hours * 3600)
  # minutes
  minutes = remain // 60
  # remaining seconds
  seconds = remain - (minutes * 60)
  # total time
  return '{:02}:{:02}:{:02}:{:02}'.format(int(hours), int(minutes), int(seconds), int(millisecondes))

def convert_time_list(times):
    list = []
    delete_flag_list = []
    diff_time = "00:00:00:00"
    for time in times:
        seconds = int(time[0] / 1000)
        millisecondes = (time[0] % 1000)
        td = datetime.timedelta(seconds=seconds, milliseconds=millisecondes)
        start_time = format_timedelta(td)
        if start_time != diff_time:
           delete_flag_list.append(1)
           delete_flag_list.append(0)
        else:
           delete_flag_list.append(0)
        #print('start_time: ', format_timedelta(td))

        seconds=int(time[1] / 1000)
        millisecondes = int(time[1] % 1000)
        td = datetime.timedelta(seconds=seconds, milliseconds=millisecondes)
        #print('end_time: ', format_timedelta(td))
        end_time = format_timedelta(td)
        diff_time = end_time
        
        list.append([start_time, end_time])
    return list, delete_flag_list

def Cut(file_path):
    path_list = file_path.split("\\")
    filename = path_list[len(path_list) - 1].replace(".mp4", "")
    dt_now = datetime.datetime.now()
    ffmpeg_output_filename = ".\\outputFfmpeg\\{0}_{1}.wav".format(filename, dt_now.strftime('%Y%m%d%H%M%S'))
    stream = ffmpeg.input(file_path)
    stream = ffmpeg.output(stream, ffmpeg_output_filename)
    ffmpeg.run(stream, overwrite_output=True)

    sound = AudioSegment.from_wav(ffmpeg_output_filename)
    list = split_on_silence(sound, 
                    min_silence_len = 500,
                    silence_thresh = -50,
                    keep_silence = 500,
                    with_timing = True)
    marge_audio = AudioSegment.empty()
    audio_list = []
    #cutted_sound = sum(chunks)
    for i, segment in enumerate(list):
        marge_audio = marge_audio + segment[2]
        audio_list.append([segment[0], segment[1]])
    print(audio_list)

    data = convert_time_list(audio_list)
    response = {
       "cut_position": data[0],
       "cut_flag": data[1]
    }
    return response
    #marge_audio.export('ポートフォリオ用素材_cut.wav')
    #print(audio_list)
