import { useEffect, useState } from "react";
import { os, path } from "../lib/cep/node";
import {
  csi,
  evalES,
  evalFile,
  openLinkInBrowser,
  subscribeBackgroundColor,
  evalTS,
} from "../lib/utils/bolt";

import "./main.scss";
import axios from "axios";

const Main = () => {
  const [bgColor, setBgColor] = useState("#282c34");

  //* Demonstration of Traditional string eval-based ExtendScript Interaction
  const noVoiceCut = async () => {
    let path: string = getPath()
    let data: any = await getCut(path)
    evalES(`noVoiceCut({0}, {1})`.replace("{0}", "'" + JSON.stringify(data["cut_position"]) + "'").replace("{1}", "'" + JSON.stringify(data["cut_flag"]) + "'"))
  };

  
  const setText = async () => {
    let data = await evalES(`setText()`)
    let path: string = getPath()
    const obj = JSON.parse(data);
    await createTelop(path, obj)
  }

  const getPath = (): string => {
    let element = document.getElementById("text");
    return (element as HTMLInputElement).value
  }

  async function getCut(filePath: string): Promise<any>{
    const response = await axios.post(
      `http://localhost:8000/noVoiceCut`, {
        filename: filePath
      }
    );
    console.log(response.data);
    return response.data
  }

  async function createTelop(filePath: string, obj: any): Promise<any>{
    const response = await axios.post(
      `http://localhost:8000/telop`, {
        filename: filePath,
        clips: obj
      }
    );
    console.log(response.data);
    return response.data
  }
  useEffect(() => {
    if (window.cep) {
      subscribeBackgroundColor(setBgColor);
    }
  }, []);

  return (
    <div className="app" style={{ backgroundColor: bgColor }}>
      <input type="text" id="text" name="avatar" />
      <div>
        <button onClick={noVoiceCut}>
          カット
        </button>
      </div>
      <div>
        <button onClick={setText}>文字おこし</button>
      </div>
    </div>
  );
};

export default Main;
