export type Scripts = {
  [key: string]: (...ags: any) => any;
};
