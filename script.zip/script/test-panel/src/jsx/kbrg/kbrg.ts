export const helloWorld = () => {
  alert("Hello from Bridge");
};
