export const helloWorld = () => {
  alert("Hello from Animate");
  document.path;
};
