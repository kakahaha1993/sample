export const helloWorld = () => {
  alert("Hello from InDesign");
};
