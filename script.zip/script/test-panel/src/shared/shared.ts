import config from "../../cep.config";
export const ns = config.id;
